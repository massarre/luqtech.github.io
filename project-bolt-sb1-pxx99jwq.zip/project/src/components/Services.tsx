import React, { useState } from 'react';
import { Code, Globe, Network, Monitor, Smartphone, Database, ChevronRight, Star, Clock, Users, Award } from 'lucide-react';

const Services = () => {
  const [activeService, setActiveService] = useState(0);

  const services = [
    {
      icon: Code,
      title: 'Développement Web',
      description: 'Sites vitrines, e-commerce, applications web sur mesure avec les dernières technologies.',
      detailedDescription: 'Création de solutions web modernes et performantes adaptées à vos besoins spécifiques. De la conception à la mise en ligne, nous vous accompagnons dans votre projet digital.',
      features: [
        'React, Vue.js, Angular',
        'PHP, Node.js, Python',
        'Responsive Design',
        'SEO optimisé',
        'Performance optimisée',
        'Sécurité renforcée'
      ],
      price: 'À partir de 1 500€',
      duration: '2-6 semaines',
      projects: '150+',
      satisfaction: '98%',
      technologies: ['React', 'Vue.js', 'Angular', 'Node.js', 'PHP', 'Python'],
      benefits: [
        'Interface utilisateur moderne et intuitive',
        'Optimisation pour les moteurs de recherche',
        'Compatibilité multi-navigateurs',
        'Maintenance et support inclus'
      ]
    },
    {
      icon: Globe,
      title: 'Digitalisation',
      description: 'Transformation numérique de vos processus métiers pour optimiser votre productivité.',
      detailedDescription: 'Accompagnement complet dans votre transformation digitale pour moderniser vos processus et améliorer votre efficacité opérationnelle.',
      features: [
        'Audit digital complet',
        'Automatisation des processus',
        'Workflow personnalisé',
        'Formation des équipes',
        'Intégration système',
        'Suivi et optimisation'
      ],
      price: 'Sur devis',
      duration: '1-3 mois',
      projects: '80+',
      satisfaction: '96%',
      technologies: ['API', 'Cloud', 'Automation', 'CRM', 'ERP'],
      benefits: [
        'Gain de productivité jusqu\'à 40%',
        'Réduction des erreurs manuelles',
        'Amélioration de la collaboration',
        'ROI mesurable et rapide'
      ]
    },
    {
      icon: Network,
      title: 'Réseau & Infrastructure',
      description: 'Installation, configuration et maintenance de votre infrastructure réseau.',
      detailedDescription: 'Solutions complètes pour votre infrastructure IT : conception, installation, sécurisation et maintenance de vos réseaux d\'entreprise.',
      features: [
        'Installation réseau',
        'Sécurité réseau avancée',
        'Configuration serveurs',
        'Sauvegarde automatisée',
        'Monitoring 24/7',
        'Support technique'
      ],
      price: 'À partir de 800€',
      duration: '1-4 semaines',
      projects: '120+',
      satisfaction: '99%',
      technologies: ['Cisco', 'Windows Server', 'Linux', 'Firewall', 'VPN'],
      benefits: [
        'Sécurité renforcée des données',
        'Performance réseau optimisée',
        'Disponibilité 99.9%',
        'Évolutivité garantie'
      ]
    },
    {
      icon: Monitor,
      title: 'Maintenance PC',
      description: 'Dépannage, maintenance et optimisation de vos équipements informatiques.',
      detailedDescription: 'Service complet de maintenance préventive et curative pour tous vos équipements informatiques, garantissant leur performance optimale.',
      features: [
        'Diagnostic complet',
        'Réparation hardware',
        'Nettoyage système',
        'Mise à jour sécurisée',
        'Optimisation performance',
        'Récupération de données'
      ],
      price: 'À partir de 80€',
      duration: '2h-2 jours',
      projects: '500+',
      satisfaction: '97%',
      technologies: ['Windows', 'macOS', 'Linux', 'Hardware', 'Software'],
      benefits: [
        'Intervention rapide sous 24h',
        'Diagnostic gratuit',
        'Garantie sur les réparations',
        'Conseils personnalisés'
      ]
    },
    {
      icon: Smartphone,
      title: 'Applications Mobile',
      description: 'Développement d\'applications iOS et Android natives ou hybrides.',
      detailedDescription: 'Création d\'applications mobiles performantes et ergonomiques pour iOS et Android, adaptées à vos besoins métiers et utilisateurs.',
      features: [
        'iOS & Android natif',
        'React Native & Flutter',
        'Design UX/UI moderne',
        'Publication App Store',
        'Maintenance évolutive',
        'Analytics intégrées'
      ],
      price: 'À partir de 3 000€',
      duration: '2-4 mois',
      projects: '45+',
      satisfaction: '95%',
      technologies: ['React Native', 'Flutter', 'Swift', 'Kotlin', 'Firebase'],
      benefits: [
        'Interface native optimisée',
        'Performance élevée',
        'Fonctionnalités offline',
        'Notifications push'
      ]
    },
    {
      icon: Database,
      title: 'Bases de Données',
      description: 'Conception, optimisation et maintenance de vos bases de données.',
      detailedDescription: 'Solutions complètes de gestion de données : architecture, optimisation, sécurisation et maintenance de vos systèmes de bases de données.',
      features: [
        'MySQL, PostgreSQL',
        'MongoDB, Redis',
        'Optimisation requêtes',
        'Sauvegardes automatiques',
        'Migration de données',
        'Monitoring performance'
      ],
      price: 'À partir de 500€',
      duration: '1-6 semaines',
      projects: '90+',
      satisfaction: '98%',
      technologies: ['MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'ElasticSearch'],
      benefits: [
        'Performance optimisée',
        'Sécurité des données',
        'Scalabilité assurée',
        'Backup automatisé'
      ]
    },
  ];

  const CurrentIcon = services[activeService].icon;

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Nos Services
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Des solutions complètes et innovantes pour tous vos besoins informatiques.
            Expertise technique de pointe et accompagnement personnalisé pour votre réussite.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl shadow-lg p-8 hover:shadow-2xl transition-all duration-500 group cursor-pointer transform hover:-translate-y-2 ${
                activeService === index ? 'ring-4 ring-blue-500 ring-opacity-50' : ''
              }`}
              onClick={() => setActiveService(index)}
            >
              <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon className="w-10 h-10 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{service.projects}</div>
                  <div className="text-xs text-gray-500">Projets</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{service.satisfaction}</div>
                  <div className="text-xs text-gray-500">Satisfaction</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{service.duration}</div>
                  <div className="text-xs text-gray-500">Délai</div>
                </div>
              </div>
              
              <div className="border-t pt-6">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-blue-600">
                    {service.price}
                  </span>
                  <button className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors flex items-center group">
                    Devis
                    <ChevronRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Detailed Service View */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mr-4">
                  <CurrentIcon className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-gray-900">{services[activeService].title}</h3>
                  <p className="text-blue-600 font-semibold">{services[activeService].price}</p>
                </div>
              </div>
              
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                {services[activeService].detailedDescription}
              </p>

              <div className="mb-8">
                <h4 className="text-xl font-bold text-gray-900 mb-4">Technologies utilisées</h4>
                <div className="flex flex-wrap gap-3">
                  {services[activeService].technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <Clock className="w-5 h-5 text-blue-600 mr-2" />
                    <span className="font-semibold text-gray-900">Délai</span>
                  </div>
                  <p className="text-gray-600">{services[activeService].duration}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <Star className="w-5 h-5 text-yellow-500 mr-2" />
                    <span className="font-semibold text-gray-900">Satisfaction</span>
                  </div>
                  <p className="text-gray-600">{services[activeService].satisfaction}</p>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-xl font-bold text-gray-900 mb-6">Fonctionnalités incluses</h4>
              <div className="space-y-4 mb-8">
                {services[activeService].features.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <div className="w-3 h-3 bg-blue-600 rounded-full mr-4"></div>
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              <h4 className="text-xl font-bold text-gray-900 mb-6">Avantages</h4>
              <div className="space-y-4 mb-8">
                {services[activeService].benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <Award className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>

              <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 flex items-center justify-center group">
                Demander un devis personnalisé
                <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-3xl p-12 max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold mb-4">
              Prêt à démarrer votre projet ?
            </h3>
            <p className="text-xl mb-8 opacity-90">
              Contactez-nous dès maintenant pour un devis gratuit et personnalisé
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors">
                Consultation gratuite
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                Voir nos réalisations
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;