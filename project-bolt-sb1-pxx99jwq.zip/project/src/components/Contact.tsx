import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle, Calendar, MessageSquare, Zap } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: '',
    budget: '',
    timeline: '',
    message: '',
    urgency: 'normal'
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    setIsSubmitted(true);
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        company: '',
        service: '',
        budget: '',
        timeline: '',
        message: '',
        urgency: 'normal'
      });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const services = [
    'Développement Web',
    'Application Mobile',
    'Réseau & Infrastructure',
    'Maintenance PC',
    'Digitalisation',
    'Base de données',
    'Consultation IT',
    'Formation',
    'Autre'
  ];

  const budgetRanges = [
    'Moins de 1 000€',
    '1 000€ - 5 000€',
    '5 000€ - 15 000€',
    '15 000€ - 50 000€',
    'Plus de 50 000€',
    'À discuter'
  ];

  const timelineOptions = [
    'Urgent (moins d\'1 semaine)',
    'Rapide (1-4 semaines)',
    'Standard (1-3 mois)',
    'Flexible (3+ mois)',
    'À planifier'
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Contactez-nous
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Prêt à démarrer votre projet ? Contactez-nous dès maintenant 
            pour un devis gratuit et personnalisé. Notre équipe d'experts est là pour vous accompagner.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl shadow-2xl p-8 lg:p-12">
              {!isSubmitted ? (
                <>
                  <div className="flex items-center mb-8">
                    <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mr-4">
                      <Send className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-3xl font-bold text-gray-900">Demande de devis</h3>
                      <p className="text-gray-600">Décrivez-nous votre projet en détail</p>
                    </div>
                  </div>
                  
                  <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Personal Information */}
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h4>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Nom complet *
                          </label>
                          <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                            placeholder="Votre nom complet"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Email *
                          </label>
                          <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                            placeholder="votre@email.com"
                          />
                        </div>
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-6 mt-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Téléphone
                          </label>
                          <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                            placeholder="01 23 45 67 89"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Entreprise
                          </label>
                          <input
                            type="text"
                            name="company"
                            value={formData.company}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                            placeholder="Nom de votre entreprise"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Project Details */}
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-4">Détails du projet</h4>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Service souhaité *
                          </label>
                          <select
                            name="service"
                            value={formData.service}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                          >
                            <option value="">Sélectionnez un service</option>
                            {services.map((service, index) => (
                              <option key={index} value={service}>{service}</option>
                            ))}
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Budget estimé
                          </label>
                          <select
                            name="budget"
                            value={formData.budget}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                          >
                            <option value="">Sélectionnez votre budget</option>
                            {budgetRanges.map((range, index) => (
                              <option key={index} value={range}>{range}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-6 mt-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Délai souhaité
                          </label>
                          <select
                            name="timeline"
                            value={formData.timeline}
                            onChange={handleChange}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                          >
                            <option value="">Sélectionnez un délai</option>
                            {timelineOptions.map((option, index) => (
                              <option key={index} value={option}>{option}</option>
                            ))}
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Niveau d'urgence
                          </label>
                          <div className="flex space-x-4">
                            <label className="flex items-center">
                              <input
                                type="radio"
                                name="urgency"
                                value="normal"
                                checked={formData.urgency === 'normal'}
                                onChange={handleChange}
                                className="mr-2"
                              />
                              <span className="text-sm">Normal</span>
                            </label>
                            <label className="flex items-center">
                              <input
                                type="radio"
                                name="urgency"
                                value="urgent"
                                checked={formData.urgency === 'urgent'}
                                onChange={handleChange}
                                className="mr-2"
                              />
                              <span className="text-sm text-orange-600">Urgent</span>
                            </label>
                            <label className="flex items-center">
                              <input
                                type="radio"
                                name="urgency"
                                value="emergency"
                                checked={formData.urgency === 'emergency'}
                                onChange={handleChange}
                                className="mr-2"
                              />
                              <span className="text-sm text-red-600">Urgence</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Description du projet *
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        required
                        rows={6}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                        placeholder="Décrivez votre projet en détail : objectifs, fonctionnalités souhaitées, contraintes techniques, etc."
                      />
                    </div>
                    
                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 flex items-center justify-center group"
                    >
                      <Send className="mr-2 group-hover:translate-x-1 transition-transform" size={20} />
                      Envoyer la demande
                    </button>
                  </form>
                </>
              ) : (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Demande envoyée avec succès !</h3>
                  <p className="text-gray-600 mb-6">
                    Merci pour votre demande. Nous vous recontacterons dans les plus brefs délais 
                    pour discuter de votre projet.
                  </p>
                  <div className="bg-blue-50 rounded-xl p-4">
                    <p className="text-blue-800 font-semibold">
                      Temps de réponse moyen : 2-4 heures
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Informations de contact
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Phone className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Téléphone</h4>
                    <p className="text-gray-600">01 23 45 67 89</p>
                    <p className="text-sm text-gray-500">Lun-Ven 9h-18h</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Mail className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Email</h4>
                    <p className="text-gray-600">contact@luqtech.fr</p>
                    <p className="text-sm text-gray-500">Réponse sous 2h</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Adresse</h4>
                    <p className="text-gray-600">Paris, Île-de-France</p>
                    <p className="text-sm text-gray-500">Déplacements possibles</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Clock className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Horaires</h4>
                    <p className="text-gray-600">Lun-Ven: 9h-18h</p>
                    <p className="text-sm text-gray-500">Sam: 9h-12h</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-red-500 to-red-600 text-white rounded-2xl p-8">
              <div className="flex items-center mb-4">
                <Zap className="w-8 h-8 mr-3" />
                <h3 className="text-2xl font-bold">Intervention d'urgence</h3>
              </div>
              <p className="text-red-100 mb-6">
                Dépannage d'urgence disponible 24h/24 et 7j/7 
                pour vos problèmes critiques.
              </p>
              <div className="space-y-3">
                <button className="w-full bg-white text-red-600 px-6 py-3 rounded-xl font-semibold hover:bg-gray-100 transition-colors">
                  Urgence: 06 12 34 56 78
                </button>
                <p className="text-sm text-red-100 text-center">
                  Tarif majoré de 50% en urgence
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-2xl p-8">
              <div className="flex items-center mb-4">
                <Calendar className="w-8 h-8 mr-3" />
                <h3 className="text-2xl font-bold">Consultation gratuite</h3>
              </div>
              <p className="text-green-100 mb-6">
                Réservez un créneau de 30 minutes pour discuter 
                de votre projet sans engagement.
              </p>
              <button className="w-full bg-white text-green-600 px-6 py-3 rounded-xl font-semibold hover:bg-gray-100 transition-colors">
                Réserver un créneau
              </button>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-2xl p-8">
              <div className="flex items-center mb-4">
                <MessageSquare className="w-8 h-8 mr-3" />
                <h3 className="text-2xl font-bold">Chat en direct</h3>
              </div>
              <p className="text-purple-100 mb-6">
                Besoin d'une réponse rapide ? Discutez directement 
                avec notre équipe technique.
              </p>
              <button className="w-full bg-white text-purple-600 px-6 py-3 rounded-xl font-semibold hover:bg-gray-100 transition-colors">
                Démarrer le chat
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;