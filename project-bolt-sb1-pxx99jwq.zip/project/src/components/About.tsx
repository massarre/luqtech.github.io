import React from 'react';
import { Award, Users, Clock, Target } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Users, label: 'Clients satisfaits', value: '150+' },
    { icon: Award, label: 'Projets réalisés', value: '300+' },
    { icon: Clock, label: 'Années d\'expérience', value: '8' },
    { icon: Target, label: 'Taux de réussite', value: '98%' },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              À propos de Luqtech
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Passionné par l'informatique depuis plus de 8 ans, je mets mon expertise 
              au service des entreprises et particuliers. Spécialisé dans le développement 
              web, la digitalisation et la maintenance informatique, j'accompagne mes 
              clients dans leur transformation numérique.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Mon approche personnalisée et ma réactivité font de moi un partenaire 
              de confiance pour tous vos projets IT. Chaque solution est pensée pour 
              répondre précisément à vos besoins et objectifs.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <div className="bg-blue-50 text-blue-800 px-4 py-2 rounded-full font-semibold">
                Développement Web
              </div>
              <div className="bg-green-50 text-green-800 px-4 py-2 rounded-full font-semibold">
                Digitalisation
              </div>
              <div className="bg-purple-50 text-purple-800 px-4 py-2 rounded-full font-semibold">
                Réseaux
              </div>
              <div className="bg-orange-50 text-orange-800 px-4 py-2 rounded-full font-semibold">
                Maintenance PC
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gray-50 rounded-xl p-6">
              <img
                src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Expert IT Luqtech"
                className="w-full h-64 object-cover rounded-lg mb-6"
              />
              <div className="text-center">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Lucas Dupont
                </h3>
                <p className="text-blue-600 font-semibold mb-2">
                  Fondateur & Expert IT
                </p>
                <p className="text-gray-600">
                  Ingénieur en informatique, certifié Microsoft et Cisco
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-lg p-4 text-center hover:shadow-lg transition-shadow">
                  <stat.icon className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;