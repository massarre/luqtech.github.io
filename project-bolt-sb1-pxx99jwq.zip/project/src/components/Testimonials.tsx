import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Marie Dubois',
      position: 'Directrice Marketing',
      company: 'Fashionista Paris',
      content: 'Luqtech a transformé notre vision en réalité. Notre site e-commerce dépasse toutes nos attentes en termes de performance et de design.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/2381069/pexels-photo-2381069.jpeg?auto=compress&cs=tinysrgb&w=200',
    },
    {
      name: 'Dr. Pierre Martin',
      position: 'Médecin',
      company: 'Cabinet Médical',
      content: 'L\'application de gestion développée par Luqtech a révolutionné notre organisation. Gain de temps énorme et interface intuitive.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/3714743/pexels-photo-3714743.jpeg?auto=compress&cs=tinysrgb&w=200',
    },
    {
      name: 'Jean-Claude Durand',
      position: 'Gérant',
      company: 'Techno Solutions',
      content: 'Installation réseau impeccable et support technique au top. Notre équipe travaille maintenant dans des conditions optimales.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/3831645/pexels-photo-3831645.jpeg?auto=compress&cs=tinysrgb&w=200',
    },
    {
      name: 'Sophie Lemaire',
      position: 'Restauratrice',
      company: 'Restaurant Le Gourmet',
      content: 'Site web magnifique qui reflète parfaitement l\'ambiance de notre restaurant. Les réservations en ligne fonctionnent parfaitement.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=200',
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Ce que disent nos clients
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Leur satisfaction est notre priorité. Découvrez les témoignages 
            de nos clients satisfaits.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300 relative"
            >
              <Quote className="absolute top-4 right-4 text-blue-200 w-8 h-8" />
              
              <div className="flex items-center mb-4">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.position}</p>
                  <p className="text-sm text-blue-600">{testimonial.company}</p>
                </div>
              </div>
              
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <p className="text-gray-700 leading-relaxed">
                "{testimonial.content}"
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-blue-600 text-white rounded-xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">
              Prêt à rejoindre nos clients satisfaits ?
            </h3>
            <p className="text-xl mb-6">
              Contactez-nous dès maintenant pour discuter de votre projet
            </p>
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg">
              Commencer votre projet
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;