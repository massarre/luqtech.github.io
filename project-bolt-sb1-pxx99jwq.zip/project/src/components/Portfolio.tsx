import React, { useState } from 'react';
import { ExternalLink, Github, Star, Calendar, Users, Code, Zap } from 'lucide-react';

const Portfolio = () => {
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [selectedProject, setSelectedProject] = useState(null);

  const categories = ['Tous', 'E-commerce', 'Application Web', 'Infrastructure', 'Site Web', 'Application Mobile', 'Digitalisation'];

  const projects = [
    {
      title: 'Site E-commerce Mode',
      category: 'E-commerce',
      description: 'Boutique en ligne complète avec paiement sécurisé et gestion des stocks.',
      detailedDescription: 'Plateforme e-commerce moderne développée avec React et Node.js, intégrant un système de paiement Stripe, gestion avancée des stocks, tableau de bord administrateur complet et optimisation SEO.',
      image: 'https://images.pexels.com/photos/160107/pexels-photo-160107.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React', 'Node.js', 'MongoDB', 'Stripe'],
      client: 'Fashionista Paris',
      duration: '3 mois',
      team: '3 personnes',
      year: '2024',
      rating: 5,
      features: [
        'Interface utilisateur moderne et responsive',
        'Système de paiement sécurisé avec Stripe',
        'Gestion avancée des stocks et commandes',
        'Tableau de bord administrateur complet',
        'Optimisation SEO et performance',
        'Système de recommandations personnalisées'
      ],
      results: [
        'Augmentation des ventes de 150%',
        'Temps de chargement réduit de 60%',
        'Taux de conversion amélioré de 35%',
        'Note de satisfaction client : 4.9/5'
      ]
    },
    {
      title: 'Application de Gestion',
      category: 'Application Web',
      description: 'Système de gestion pour cabinet médical avec planning et dossiers patients.',
      detailedDescription: 'Application web complète pour la gestion d\'un cabinet médical, incluant la prise de rendez-vous en ligne, la gestion des dossiers patients, la facturation automatisée et les rappels automatiques.',
      image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Vue.js', 'PHP', 'MySQL', 'API REST'],
      client: 'Cabinet Dr. Martin',
      duration: '4 mois',
      team: '2 personnes',
      year: '2024',
      rating: 5,
      features: [
        'Prise de rendez-vous en ligne',
        'Gestion complète des dossiers patients',
        'Facturation automatisée',
        'Rappels automatiques par SMS/Email',
        'Tableau de bord statistiques',
        'Conformité RGPD'
      ],
      results: [
        'Gain de temps de 40% sur la gestion',
        'Réduction des no-shows de 25%',
        'Satisfaction patient : 4.8/5',
        'ROI atteint en 6 mois'
      ]
    },
    {
      title: 'Réseau Entreprise',
      category: 'Infrastructure',
      description: 'Installation complète du réseau informatique pour une PME de 50 employés.',
      detailedDescription: 'Conception et déploiement d\'une infrastructure réseau complète incluant serveurs, sécurité, sauvegarde et monitoring pour une entreprise de 50 employés.',
      image: 'https://images.pexels.com/photos/159304/network-cable-ethernet-computer-159304.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Cisco', 'Windows Server', 'Firewall', 'VPN'],
      client: 'Techno Solutions',
      duration: '2 mois',
      team: '2 personnes',
      year: '2023',
      rating: 5,
      features: [
        'Architecture réseau sécurisée',
        'Serveurs redondants',
        'Système de sauvegarde automatisé',
        'VPN pour télétravail',
        'Monitoring 24/7',
        'Formation des équipes'
      ],
      results: [
        'Disponibilité réseau : 99.9%',
        'Sécurité renforcée : 0 incident',
        'Productivité équipe +30%',
        'Coûts IT réduits de 20%'
      ]
    },
    {
      title: 'Site Vitrine Restaurant',
      category: 'Site Web',
      description: 'Site vitrine moderne avec réservation en ligne et menu interactif.',
      detailedDescription: 'Site web élégant pour restaurant avec système de réservation en ligne, menu interactif, galerie photos et intégration réseaux sociaux.',
      image: 'https://images.pexels.com/photos/1307698/pexels-photo-1307698.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['WordPress', 'CSS3', 'JavaScript', 'PHP'],
      client: 'Restaurant Le Gourmet',
      duration: '1 mois',
      team: '2 personnes',
      year: '2024',
      rating: 5,
      features: [
        'Design responsive et élégant',
        'Système de réservation en ligne',
        'Menu interactif avec photos',
        'Galerie photos haute qualité',
        'Intégration réseaux sociaux',
        'Optimisation SEO local'
      ],
      results: [
        'Réservations en ligne +200%',
        'Visibilité web +180%',
        'Nouveau clientèle +45%',
        'Note Google : 4.7/5'
      ]
    },
    {
      title: 'App Mobile Fitness',
      category: 'Application Mobile',
      description: 'Application de suivi sportif avec programmes personnalisés.',
      detailedDescription: 'Application mobile native pour le suivi d\'activités sportives avec programmes personnalisés, suivi des performances et communauté d\'utilisateurs.',
      image: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['React Native', 'Firebase', 'API REST', 'Push Notifications'],
      client: 'FitLife Coaching',
      duration: '5 mois',
      team: '4 personnes',
      year: '2023',
      rating: 4,
      features: [
        'Programmes d\'entraînement personnalisés',
        'Suivi des performances en temps réel',
        'Communauté d\'utilisateurs',
        'Notifications push intelligentes',
        'Synchronisation multi-appareils',
        'Analytics avancées'
      ],
      results: [
        '10k+ téléchargements en 3 mois',
        'Engagement utilisateur : 85%',
        'Note App Store : 4.6/5',
        'Rétention 30 jours : 70%'
      ]
    },
    {
      title: 'Digitalisation Processus',
      category: 'Digitalisation',
      description: 'Automatisation des processus comptables et facturation électronique.',
      detailedDescription: 'Transformation digitale complète des processus comptables avec automatisation de la facturation, dématérialisation des documents et tableau de bord analytique.',
      image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=600',
      tech: ['Python', 'API', 'Automation', 'Cloud'],
      client: 'Comptabilité Express',
      duration: '3 mois',
      team: '3 personnes',
      year: '2024',
      rating: 5,
      features: [
        'Automatisation facturation',
        'Dématérialisation documents',
        'Workflow de validation',
        'Tableau de bord analytique',
        'Intégration ERP existant',
        'Conformité fiscale'
      ],
      results: [
        'Temps de traitement -70%',
        'Erreurs réduites de 90%',
        'Coûts opérationnels -40%',
        'ROI atteint en 4 mois'
      ]
    },
  ];

  const filteredProjects = projects.filter(project => 
    selectedCategory === 'Tous' || project.category === selectedCategory
  );

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Nos Réalisations
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Découvrez nos projets récents et les solutions innovantes 
            que nous avons développées pour nos clients. Chaque projet reflète notre expertise 
            et notre engagement envers l'excellence.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-100 shadow-md'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {filteredProjects.map((project, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 group cursor-pointer"
              onClick={() => setSelectedProject(project)}
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {project.category}
                  </span>
                </div>
                <div className="absolute top-4 right-4">
                  <div className="flex items-center bg-white bg-opacity-90 rounded-full px-2 py-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm font-semibold ml-1">{project.rating}</span>
                  </div>
                </div>
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity duration-300 flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-4">
                    <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors">
                      <ExternalLink size={20} />
                    </button>
                    <button className="bg-white text-gray-900 p-3 rounded-full hover:bg-gray-100 transition-colors">
                      <Github size={20} />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                    {project.title}
                  </h3>
                  <span className="text-sm text-gray-500">{project.year}</span>
                </div>
                
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {project.description}
                </p>

                <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>{project.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-1" />
                    <span>{project.team}</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.slice(0, 3).map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.tech.length > 3 && (
                    <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                      +{project.tech.length - 3}
                    </span>
                  )}
                </div>
                
                <div className="border-t pt-4">
                  <p className="text-sm text-gray-500">
                    <span className="font-semibold">Client:</span> {project.client}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Project Modal */}
        {selectedProject && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="relative">
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-64 object-cover"
                />
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 bg-white text-gray-900 p-2 rounded-full hover:bg-gray-100"
                >
                  ×
                </button>
                <div className="absolute bottom-4 left-4">
                  <span className="bg-blue-600 text-white px-4 py-2 rounded-full font-semibold">
                    {selectedProject.category}
                  </span>
                </div>
              </div>
              
              <div className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-3xl font-bold text-gray-900">{selectedProject.title}</h3>
                  <div className="flex items-center">
                    {[...Array(selectedProject.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
                
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  {selectedProject.detailedDescription}
                </p>

                <div className="grid md:grid-cols-2 gap-8 mb-8">
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-4">Fonctionnalités</h4>
                    <ul className="space-y-2">
                      {selectedProject.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <Zap className="w-5 h-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-4">Résultats</h4>
                    <ul className="space-y-2">
                      {selectedProject.results.map((result, index) => (
                        <li key={index} className="flex items-start">
                          <Star className="w-5 h-5 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{result}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{selectedProject.duration}</div>
                      <div className="text-sm text-gray-500">Durée</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{selectedProject.team}</div>
                      <div className="text-sm text-gray-500">Équipe</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">{selectedProject.year}</div>
                      <div className="text-sm text-gray-500">Année</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">{selectedProject.client}</div>
                      <div className="text-sm text-gray-500">Client</div>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="text-lg font-bold text-gray-900 mb-3">Technologies utilisées</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.tech.map((tech, index) => (
                        <span
                          key={index}
                          className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full font-semibold"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <button className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors">
                      Voir le projet
                    </button>
                    <button className="flex-1 border-2 border-blue-600 text-blue-600 py-3 rounded-xl font-semibold hover:bg-blue-600 hover:text-white transition-colors">
                      Projet similaire
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Call to Action */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-3xl p-12 max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold mb-4">
              Prêt à créer votre prochain projet ?
            </h3>
            <p className="text-xl mb-8 opacity-90">
              Discutons de vos besoins et créons ensemble une solution sur mesure
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors">
                Démarrer un projet
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                Voir tous nos projets
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;